

<?php $__env->startSection('title', 'Editions'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Editions Page</h1>
    <div class="container">
    <h3>Manage Editions</h3>

    <?php if(session('success')): ?>
        <p class="success"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    
    <form method="POST" action="<?php echo e(route('editions.store')); ?>" class="edition-form">
        <?php echo csrf_field(); ?>

        <input type="text" name="publication_name" required placeholder="Enter Publication Name">
        <select name="publication_type" required>
            <option value="">Select Type</option>
            <option value="Newspaper">Newspaper</option>
            <option value="Magazine">Magazine</option>
        </select>
        <input type="date" name="edition_date" required>
        <button type="submit">Create Edition</button>
    </form>

    
    <table class="edition-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Type</th>
                <th>Edition Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $editions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <form method="POST" action="<?php echo e(route('editions.update', $edition->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <select name="publication_type" required>
                                <option value="Newspaper" <?php echo e($edition->publication_type == 'Newspaper' ? 'selected' : ''); ?>>Newspaper</option>
                                <option value="Magazine" <?php echo e($edition->publication_type == 'Magazine' ? 'selected' : ''); ?>>Magazine</option>
                            </select>
                        </td>

                         <!-- Publication Name (new input) -->
                        <td>
                            <input type="text" name="publication_name" value="<?php echo e($edition->publication_name); ?>" required placeholder="Enter name (e.g. The Hindu)">
                        </td>
                        <td>
                            <input type="date" name="edition_date" value="<?php echo e($edition->edition_date); ?>" required>
                        </td>
                        <td>
                            <button type="submit">Update</button>
                    </form>
                    <form method="POST" action="<?php echo e(route('editions.destroy', $edition->id)); ?>" onsubmit="return confirm('Are you sure you want to delete this edition?');" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Delete</button>
                    </form>
                        </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<style>
.container {
    max-width: 850px;
    margin: 20px auto;
    padding: 25px;
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 14px rgba(0,0,0,0.1);
}

h3 {
    margin-bottom: 20px;
    color: #2c3e50;
}

.success {
    background: #e0f9e0;
    color: green;
    padding: 10px;
    border-radius: 6px;
    margin-bottom: 10px;
}

.edition-form {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
}

.edition-form select,
.edition-form input,
.edition-form button {
    padding: 8px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

.edition-table {
    width: 100%;
    border-collapse: collapse;
}

.edition-table th,
.edition-table td {
    padding: 10px;
    border: 1px solid #eee;
}

.edition-table select,
.edition-table input {
    width: 100%;
    padding: 5px;
}
</style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\inter\e-paper\resources\views/editions/index.blade.php ENDPATH**/ ?>