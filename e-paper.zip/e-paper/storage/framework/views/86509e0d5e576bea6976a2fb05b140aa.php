

<?php $__env->startSection('title', 'All Pages from All Editions'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="section-title">All Pages from All Editions</h2>

   <div class="editions-wrapper">
    <?php $__currentLoopData = $editions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="edition-card">
            <div class="edition-header clickable" data-url="<?php echo e(route('pages.index', $edition->id)); ?>">
               <div>
                <h3><?php echo e($edition->publication_name); ?></h3><br>
                <p style="font-size: 0.95rem; color: #666;"><?php echo e($edition->publication_type); ?></p>
            </div>
                <span class="edition-date"><?php echo e($edition->edition_date); ?></span>
            </div>

            <div class="pages-grid">
                <?php $__currentLoopData = $edition->pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="page-card">
                        <p>Page <?php echo e($page->page_number); ?></p>
                        <img src="<?php echo e(asset('storage/' . $page->image_path)); ?>" alt="Page <?php echo e($page->page_number); ?>">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


    <style>
        .section-title {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2rem;
            color: #2c3e50;
        }

        .editions-wrapper {
            display: flex;
            flex-direction: column;
            gap: 40px;
        }

        .edition-card {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.06);
        }

        .edition-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .edition-header h3 {
            font-size: 1.5rem;
            color: #2980b9;
        }

        .edition-date {
            background-color: #ecf0f1;
            padding: 5px 10px;
            border-radius: 6px;
            color: #555;
            font-size: 0.9rem;
        }

        .pages-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 20px;
        }

        .page-card {
            text-align: center;
            background: #f9f9f9;
            border-radius: 8px;
            padding: 10px;
            transition: transform 0.2s ease;
        }

        .page-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.1);
        }

        .page-card img {
            width: 80px; /* or 100px */
            height: auto;
            border-radius: 4px;
            object-fit: cover;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }


        .page-card p {
            margin: 10px 0 5px;
            font-weight: bold;
            color: #34495e;
        }
    </style>
    <script>
    document.querySelectorAll('.edition-header.clickable').forEach(function(element) {
        element.style.cursor = 'pointer'; // show pointer on hover

        element.addEventListener('click', function() {
            const url = this.getAttribute('data-url');
            if(url) {
                window.location.href = url;
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\inter\e-paper\resources\views/pages/all.blade.php ENDPATH**/ ?>